<?php echo $__env->make('admin_panel.include.header_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div class="page-wrapper default-version">
        <?php echo $__env->make('admin_panel.include.sidebar_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin_panel.include.navbar_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="body-wrapper">
            <div class="bodywrapper__inner">
                <div class="d-flex mb-4 flex-wrap gap-3 justify-content-between align-items-center">
                    <h4 class="fw-bold text-primary"> Available Trucks for Sale</h4>
                </div>
                <div class="card shadow-lg">
                    <div class="card-body">
                        <div class="table-responsive--sm table-responsive">
                            <table id="example" class="display  table table--light" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>Truck Number</th>
                                        <th>Vendor</th>
                                        <th>Arrival Date</th>
                                        <th>Total Available Units</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $trucks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($truck->truck_number); ?></td>
                                        <td><?php echo e($truck->vendor_id); ?></td>
                                        <td><?php echo e($truck->entry_date); ?></td>
                                        <td><?php echo e($truck->total_units); ?></td>
                                        <td>
                                            <?php if($truck->total_units > 0): ?>
                                            <a href="<?php echo e(route('show-Lots', $truck->id)); ?>" class="btn btn-primary btn-sm">Sale</a>
                                            <?php else: ?>
                                            <span class="btn btn-danger btn-sm">Units Sold</span>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('sale-record', $truck->id)); ?>" class="btn btn-success btn-sm">Sale Record</a>

                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('admin_panel.include.footer_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



</body><?php /**PATH C:\xampp\htdocs\Jan_muhammad_CO\resources\views/admin_panel/lot_sale/truck_list.blade.php ENDPATH**/ ?>