<?php echo $__env->make('admin_panel.include.header_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div class="page-wrapper default-version">
        <?php echo $__env->make('admin_panel.include.sidebar_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin_panel.include.navbar_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="body-wrapper">
            <div class="bodywrapper__inner">
                <div class="d-flex mb-30 flex-wrap gap-3 justify-content-between align-items-center">
                    <h6 class="page-title">Truck Entries</h6>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive--sm table-responsive">
                            <table id="example" class="display  table table--light" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Truck Number</th>
                                        <th>Driver Name</th>
                                        <th>Vendor</th>
                                        <th>Entry Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $truckEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($entry->truck_number); ?></td>
                                        <td><?php echo e($entry->driver_name); ?></td>
                                        <td><?php echo e($entry->vendor_id); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime($entry->entry_date))); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('Truck-Entry.Show', $entry->id)); ?>" class="btn btn-primary btn-sm">View</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php echo $__env->make('admin_panel.include.footer_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body><?php /**PATH C:\xampp\htdocs\Jan_muhammad_CO\resources\views/admin_panel/Truck_entry/truck_enteries.blade.php ENDPATH**/ ?>