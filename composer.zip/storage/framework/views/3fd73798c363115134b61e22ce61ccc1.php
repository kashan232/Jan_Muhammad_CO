<div class="sidebar bg--dark">
    <button class="res-sidebar-close-btn"><i class="la la-times"></i></button>
    <div class="sidebar__inner">
        <div class="sidebar__logo">
            <a href="#" class="sidebar__main-logo">
                <img src="<?php echo e(asset('logo_white.png')); ?>" alt="image">
            </a>
        </div>
        <div class="sidebar__menu-wrapper" id="sidebar__menuWrapper">
            <?php if(Auth::check() && Auth::user()->usertype == 'admin'): ?>
            <ul class="sidebar__menu">
                <li class="sidebar-menu-item ">
                    <a href="<?php echo e(route('home')); ?>" class="nav-link ">
                        <i class="menu-icon la la-home"></i>
                        <span class="menu-title">Dashboard</span>
                    </a>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a  href="javascript:void(0)">
                        <i class="menu-icon fas fa-truck"></i>
                        <span class="menu-title">Products</span>
                    </a>
                    <div class="sidebar-submenu ">
                        <ul>
                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('category')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Products </span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('brand')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Verity</span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('unit')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Units</span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('In-unit')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Units In</span>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>


                <li class="sidebar-menu-item sidebar-dropdown">
                    <a  href="javascript:void(0)">
                        <i class="menu-icon las la-users"></i>
                        <span class="menu-title">Customer</span>
                    </a>
                    <div class="sidebar-submenu ">
                        <ul>
                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('customer')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Customers</span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('customer-ledger')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Cutomers Ledger</span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('customer-recovery')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Cutomers Recoveries</span>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>  

                

                <li class="sidebar-menu-item">
                    <a href="<?php echo e(route('supplier')); ?>" class="nav-link">
                        <i class="menu-icon la la-user-friends"></i>
                        <span class="menu-title">Vendor</span>
                    </a>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a  href="javascript:void(0)">
                        <i class="menu-icon fas fa-truck"></i>
                        <span class="menu-title">Truck Entry</span>
                    </a>
                    <div class="sidebar-submenu ">
                        <ul>
                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('Truck-Entry')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Add Truck Entry </span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('Truck-Entries')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Trucks Enter</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a  href="javascript:void(0)">
                        <i class="menu-icon fas fa-truck"></i>
                        <span class="menu-title"> Sale</span>
                    </a>
                    <div class="sidebar-submenu ">
                        <ul>
                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('show-trucks')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"> sale </span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('customer-sale')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title"> Customer sale </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?php echo e(route('cash-sale')); ?>" class="nav-link">
                        <i class="menu-icon fas fa-money-bill"></i>
                        <span class="menu-title">Cash Sale</span>
                    </a><i class=""></i>
                </li>

               <!-- <li class="sidebar-menu-item sidebar-dropdown">
                    <a class="" href="javascript:void(0)">
                        <i class="menu-icon las la-users"></i>
                        <span class="menu-title">Manage Staff</span>
                    </a>
                    <div class="sidebar-submenu ">
                        <ul>
                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('staff')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">All Staff</span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item ">
                                <a class="nav-link" href="<?php echo e(route('StaffSalary')); ?>">
                                    <i class="menu-icon las la-dot-circle"></i>
                                    <span class="menu-title">Staff Salary</span>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>  -->

                <!-- <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="">
                        <i class="menu-icon lab la-product-hunt"></i>
                        <span class="menu-title">Manage Product</span>
                    </a>
                    <div class="sidebar-submenu  ">
                        <ul>
                            <li class="sidebar-menu-item  ">
                                <a href="<?php echo e(route('category')); ?>" class="nav-link">
                                    <i class="menu-icon la la-dot-circle"></i>
                                    <span class="menu-title">Categories</span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item  ">
                                <a href="<?php echo e(route('subcategory')); ?>" class="nav-link">
                                    <i class="menu-icon la la-dot-circle"></i>
                                    <span class="menu-title">Sub Categories</span>
                                </a>
                            </li>
                            
                            <li class="sidebar-menu-item  ">
                                <a href="<?php echo e(route('unit')); ?>" class="nav-link">
                                    <i class="menu-icon la la-dot-circle"></i>
                                    <span class="menu-title">Units</span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item  ">
                                <a href="<?php echo e(route('all-product')); ?>"
                                    class="nav-link">
                                    <i class="menu-icon la la-dot-circle"></i>
                                    <span class="menu-title">Products</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li> -->

                <!-- <li class="sidebar-menu-item ">
                    <a href="<?php echo e(route('all-order')); ?>" class="nav-link ">
                        <i class="menu-icon la la-warehouse"></i>
                        <span class="menu-title">Order</span>
                    </a>
                </li> -->
                <!-- <li class="sidebar-menu-item ">
                    <a href="<?php echo e(route('product-alerts')); ?>" class="nav-link ">
                        <i class="menu-icon las la-bell"></i>
                        <span class="menu-title">Stock Alerts</span>
                        
                    </a>
                </li> -->

                




                 <!-- <li class="sidebar-menu-item">
                    <a href="<?php echo e(route('supplier')); ?>" class="nav-link">
                        <i class="menu-icon la la-user-friends"></i>
                        <span class="menu-title">Supplier</span>
                    </a>
                </li> 
                 <li class="sidebar-menu-item">
                    <a href="<?php echo e(route('supplier')); ?>" class="nav-link">
                        <i class="menu-icon la la-user-friends"></i>
                        <span class="menu-title">Vendor</span>
                    </a>
                </li>  -->
                <!-- <li class="sidebar-menu-item">
                    <a href="<?php echo e(route('vendor')); ?>" class="nav-link">
                        <i class="menu-icon la la-user-friends"></i>
                        <span class="menu-title">Vendor</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?php echo e(route('vendor')); ?>" class="nav-link">
                        <i class="menu-icon la la-user-friends"></i>
                        <span class="menu-title">Give Order to Vendor</span>
                    </a>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="">
                        <i class="menu-icon la la-shopping-bag"></i>
                        <span class="menu-title">Purchase</span>
                    </a>
                    <div class="sidebar-submenu  ">
                        <ul>
                            <li class="sidebar-menu-item  ">
                                <a href="<?php echo e(route('Purchase')); ?>"
                                    class="nav-link">
                                    <i class="menu-icon la la-dot-circle"></i>
                                    <span class="menu-title">All Purchases</span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item  ">
                                <a href="<?php echo e(route('all-purchase-return')); ?>"
                                    class="nav-link">
                                    <i class="menu-icon la la-dot-circle"></i>
                                    <span class="menu-title">Purchases Return</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item  ">
                    <a href="<?php echo e(route('all-purchase-return-damage-item')); ?>"
                        class="nav-link">
                        <i class="menu-icon la la-dot-circle"></i>
                        <span class="menu-title">Claim Returns</span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a href="<?php echo e(route('customer')); ?>" class="nav-link">
                        <i class="menu-icon la la-users"></i>
                        <span class="menu-title">Customer</span>
                    </a>
                </li>

                
                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="">
                        <i class="menu-icon la la-shopping-cart"></i>
                        <span class="menu-title">Sale</span>
                    </a>
                    <div class="sidebar-submenu">
                        <ul>
                            <li class="sidebar-menu-item">
                                <a href="<?php echo e(route('all-sales')); ?>" class="nav-link">
                                    <i class="menu-icon la la-dot-circle"></i>
                                    <span class="menu-title">All Sales</span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item  ">
                                <a href="#"
                                    class="nav-link">
                                    <i class="menu-icon la la-dot-circle"></i>
                                    <span class="menu-title">Sales Return</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>  -->
            </ul>
            <?php endif; ?>

            <div class="text-center mb-3 text-uppercase">
                <span class="text--warning">Jan</span>
                <span class="text--primary">Muhammad</span>
                <span class="text--warning">CO</span>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Jan_muhammad_CO\resources\views/admin_panel/include/sidebar_include.blade.php ENDPATH**/ ?>