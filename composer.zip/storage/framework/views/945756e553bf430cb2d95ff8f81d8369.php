<?php echo $__env->make('admin_panel.include.header_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <!-- page-wrapper start -->
    <div class="page-wrapper default-version">

        <!-- sidebar start -->

        <?php echo $__env->make('admin_panel.include.sidebar_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- sidebar end -->

        <!-- navbar-wrapper start -->
        <?php echo $__env->make('admin_panel.include.navbar_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- navbar-wrapper end -->

        <div class="body-wrapper">
            <div class="bodywrapper__inner">

                <div class="d-flex mb-30 flex-wrap gap-3 justify-content-between align-items-center">
                    <h6 class="page-title">Cash Sale</h6>

                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card b-radius--10">
                            <div class="card-body p-0">
                                <div class="table-responsive--sm table-responsive">
                                    <table class="table--light style--two table">
                                        <thead>
                                            <tr>
                                                <th>Sale Date</th>
                                                <th>Category</th>
                                                <th>Variety</th>
                                                <th>Sold Units</th>
                                                <th>Price</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $cash_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($sale->sale_date); ?></td>
                                                <td><?php echo e($sale->category); ?></td>
                                                <td><?php echo e($sale->variety); ?></td>
                                                <td><?php echo e($sale->quantity); ?></td>
                                                <td><?php echo e($sale->price); ?></td>
                                                <td><?php echo e($sale->total); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- bodywrapper__inner end -->
        </div><!-- body-wrapper end -->
    </div>
    <?php echo $__env->make('admin_panel.include.footer_include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Jan_muhammad_CO\resources\views/admin_panel/lot_sale/cash_sale.blade.php ENDPATH**/ ?>